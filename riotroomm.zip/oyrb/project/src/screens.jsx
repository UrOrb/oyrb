// Landing screen — the scrollable profile page inside the phone.
// One screen, theme-driven. This is what every template shows on arrival.

const { useState: useStateS, useEffect: useEffectS } = React;

function TopBar({ t, onMenu }) {
  const isDark = t.bg.startsWith('#0') || t.bg.startsWith('#1');
  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 10,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '60px 20px 10px',
      background: `${t.bg}dd`,
      backdropFilter: 'blur(14px)',
      borderBottom: `1px solid ${t.line}`,
    }}>
      <div style={{
        fontFamily: t.display, fontWeight: t.displayWeight,
        fontSize: 16, color: t.ink,
        letterSpacing: t.id === 'street' ? 0.1 : 0,
        textTransform: t.id === 'street' ? 'uppercase' : 'none',
      }}>{t.business}</div>
      <div style={{ display: 'flex', gap: 10 }}>
        <IconBtn t={t} onClick={onMenu} label="share">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={t.ink} strokeWidth="1.4"><path d="M8 11V2m0 0L4 6m4-4l4 4M3 11v2a1 1 0 001 1h8a1 1 0 001-1v-2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </IconBtn>
        <IconBtn t={t} onClick={onMenu} label="save">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={t.ink} strokeWidth="1.4"><path d="M8 14s-5-3.2-5-7a3 3 0 015-2 3 3 0 015 2c0 3.8-5 7-5 7z"/></svg>
        </IconBtn>
      </div>
    </div>
  );
}

function IconBtn({ t, children, onClick, label }) {
  return (
    <button onClick={onClick} aria-label={label} style={{
      width: 36, height: 36, borderRadius: t.radiusBtn,
      background: t.surface, border: `1px solid ${t.line}`, cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0,
    }}>{children}</button>
  );
}

// ── HERO section — many theme-specific treatments ──
function Hero({ t, onBook }) {
  // Theme-specific hero layouts
  if (t.id === 'luxe') {
    return (
      <div style={{ background: t.bg, padding: '28px 20px 40px', position: 'relative' }}>
        <div style={{ position: 'absolute', top: 28, right: 20, fontFamily: t.mono, fontSize: 9, color: t.accent, letterSpacing: 3, writingMode: 'vertical-rl' }}>EST. MMXVIII</div>
        <Kicker t={t} style={{ marginBottom: 20 }}>Private Studio · By Appointment</Kicker>
        <Headline t={t} size={56} italic style={{ marginBottom: 10 }}>Midnight<br/><span style={{ color: t.accent, fontStyle: 'italic' }}>Atelier</span></Headline>
        <Ornament t={t} style={{ margin: '18px 0' }}/>
        <Body t={t} size={14} color={t.mute}>{t.tagline}</Body>
        <Placeholder t={t} label={IMAGES.hero} ratio="4 / 5" style={{ marginTop: 24 }} radius={2}/>
        <div style={{ marginTop: 24 }}>
          <TButton t={t} full onClick={onBook} variant="accent">Request Appointment</TButton>
        </div>
      </div>
    );
  }

  if (t.id === 'bold') {
    return (
      <div style={{ background: t.ink, color: t.bg, padding: '24px 20px 28px' }}>
        <Kicker t={t} style={{ color: t.accent, marginBottom: 14 }}>◼ OPEN FOR BOOKING</Kicker>
        <div style={{ fontFamily: t.display, fontWeight: 900, fontSize: 68, lineHeight: 0.88, letterSpacing: '-0.045em', color: t.bg }}>
          BLOCK.<br/><span style={{ color: t.accent }}>STU&shy;DIO</span>
        </div>
        <div style={{ marginTop: 16, display: 'flex', gap: 6, alignItems: 'center' }}>
          <div style={{ width: 10, height: 10, background: t.accent }}/>
          <div style={{ fontFamily: t.mono, fontSize: 11, letterSpacing: 1, color: t.bg }}>{t.tagline.toUpperCase()}</div>
        </div>
        <div style={{ marginTop: 20, position: 'relative' }}>
          <Placeholder t={t} label={IMAGES.hero} ratio="4 / 5" radius={8} dark/>
          <div style={{ position: 'absolute', bottom: -12, left: -4, background: t.accent, color: t.ink, fontFamily: t.display, fontWeight: 900, fontSize: 14, padding: '6px 12px', letterSpacing: 1 }}>NEW WORK ⟶</div>
        </div>
        <div style={{ marginTop: 28 }}>
          <TButton t={t} full onClick={onBook} variant="accent">BOOK NOW →</TButton>
        </div>
      </div>
    );
  }

  if (t.id === 'street') {
    return (
      <div style={{ background: t.bg, color: t.ink, padding: '20px 18px 28px', position: 'relative' }}>
        <div style={{ fontFamily: t.mono, fontSize: 10, color: t.accent, letterSpacing: 2, marginBottom: 8 }}>
          // SHOP_02 · OAK · EST_2019 · ACCEPTING CLIENTS
        </div>
        <div style={{ fontFamily: t.display, fontWeight: 800, fontSize: 64, lineHeight: 0.85, letterSpacing: '-0.045em', color: t.ink, textTransform: 'uppercase' }}>
          SHEAR<span style={{ color: t.accent }}>/</span>CODE
        </div>
        <div style={{ marginTop: 12, border: `1px solid ${t.line}`, padding: '10px 12px', display: 'flex', justifyContent: 'space-between', fontFamily: t.mono, fontSize: 10, letterSpacing: 1, color: t.mute, textTransform: 'uppercase' }}>
          <span>BY APPT · ONLY</span>
          <span style={{ color: t.accent }}>● LIVE</span>
        </div>
        <div style={{ marginTop: 14, position: 'relative' }}>
          <Placeholder t={t} label={IMAGES.hero} ratio="1 / 1" radius={0} dark/>
          <div style={{ position: 'absolute', top: 10, left: 10, padding: '4px 8px', background: t.accent, color: t.ink, fontFamily: t.mono, fontSize: 10, fontWeight: 700, letterSpacing: 1 }}>CLIENT_048</div>
        </div>
        <div style={{ marginTop: 14, fontFamily: t.body, fontSize: 13, color: t.mute, lineHeight: 1.5 }}>{t.tagline}</div>
        <div style={{ marginTop: 20 }}>
          <TButton t={t} full onClick={onBook} variant="accent">▸ BOOK THE CHAIR</TButton>
        </div>
      </div>
    );
  }

  if (t.id === 'y2k') {
    return (
      <div style={{ background: `linear-gradient(180deg, ${t.accent2}22 0%, ${t.bg} 40%)`, padding: '24px 20px 32px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: 40, right: -20, fontSize: 120, opacity: 0.25, color: t.accent }}>★</div>
        <Kicker t={t} style={{ marginBottom: 8 }}>OPEN · come thru!!</Kicker>
        <div style={{ fontFamily: t.display, fontWeight: 900, fontSize: 62, lineHeight: 0.9, letterSpacing: '-0.03em', color: t.ink }}>
          glossbaby<span style={{ color: t.accent }}>☆</span>
        </div>
        <div style={{ marginTop: 8, fontFamily: t.body, fontSize: 15, color: t.mute, fontWeight: 500 }}>{t.tagline}</div>
        <div style={{ marginTop: 18, position: 'relative' }}>
          <div style={{ borderRadius: 28, overflow: 'hidden', border: `3px solid ${t.ink}`, boxShadow: `6px 6px 0 0 ${t.accent2}` }}>
            <Placeholder t={t} label={IMAGES.hero} ratio="4 / 5" radius={24}/>
          </div>
          <div style={{ position: 'absolute', top: -10, right: -6, background: t.accent, color: t.surface, fontFamily: t.display, fontWeight: 900, fontSize: 13, padding: '8px 12px', borderRadius: 999, border: `2px solid ${t.ink}`, transform: 'rotate(8deg)' }}>✧ NEW SET ✧</div>
        </div>
        <div style={{ marginTop: 24 }}>
          <TButton t={t} full onClick={onBook} variant="primary">☆ book me ☆</TButton>
        </div>
      </div>
    );
  }

  if (t.id === 'graffiti') {
    return (
      <div style={{ background: t.bg, padding: '22px 18px 28px', position: 'relative', overflow: 'hidden' }}>
        {/* spray splats */}
        <div style={{ position: 'absolute', top: 40, right: -30, width: 160, height: 160, background: t.accent, borderRadius: '42% 58% 60% 40% / 55% 45% 55% 45%', opacity: 0.9, filter: 'blur(1px)' }}/>
        <div style={{ position: 'absolute', top: 140, left: -24, width: 90, height: 90, background: t.accent2, borderRadius: '55% 45% 60% 40% / 50% 50% 50% 50%', opacity: 0.85 }}/>
        <div style={{ position: 'absolute', top: 58, right: 40, fontFamily: '"Permanent Marker", cursive', fontSize: 22, color: t.ink, transform: 'rotate(-8deg)' }}>★</div>

        <div style={{ position: 'relative', zIndex: 2 }}>
          <div style={{ display: 'inline-block', background: t.ink, color: t.accent, fontFamily: t.mono, fontSize: 10, letterSpacing: 2, padding: '4px 10px', textTransform: 'uppercase' }}>▶ NOW SPRAYING</div>
          <div style={{ marginTop: 14, fontFamily: t.display, fontSize: 72, lineHeight: 0.82, letterSpacing: '-0.02em', color: t.ink, textTransform: 'uppercase' }}>
            RIOT<br/>
            <span style={{ WebkitTextStroke: `2px ${t.ink}`, color: 'transparent' }}>ROOM</span>
          </div>
          <div style={{ marginTop: 14, fontFamily: '"Permanent Marker", cursive', fontSize: 20, color: t.ink, transform: 'rotate(-2deg)', display: 'inline-block', background: t.accent2, padding: '2px 10px' }}>
            {t.tagline}
          </div>

          <div style={{ marginTop: 22, position: 'relative' }}>
            <div style={{ border: `3px solid ${t.ink}`, transform: 'rotate(-1.5deg)', background: t.surface }}>
              <Placeholder t={t} label={IMAGES.hero} ratio="4 / 5" radius={0} dark/>
            </div>
            <div style={{ position: 'absolute', bottom: -12, right: -8, background: t.accent, color: t.ink, fontFamily: t.display, fontSize: 14, padding: '8px 14px', border: `2px solid ${t.ink}`, transform: 'rotate(4deg)', textTransform: 'uppercase', letterSpacing: 1 }}>GOT COLOR?</div>
            <div style={{ position: 'absolute', top: -10, left: -10, background: t.ink, color: t.accent2, fontFamily: t.mono, fontSize: 11, padding: '4px 8px', transform: 'rotate(-6deg)' }}>CLIENT #04</div>
          </div>

          <div style={{ marginTop: 28 }}>
            <TButton t={t} full onClick={onBook} variant="primary">✺ BOOK THE CHAOS</TButton>
          </div>
        </div>
      </div>
    );
  }

  if (t.id === 'trust') {
    return (
      <div style={{ background: t.bg, padding: '28px 22px 36px' }}>
        <Kicker t={t} style={{ marginBottom: 14 }}>Licensed · Inclusive · Consent-forward</Kicker>
        <Headline t={t} size={42} style={{ marginBottom: 12, letterSpacing: '-0.015em' }}>
          Care you can<br/>
          <span style={{ color: t.accent, fontStyle: 'italic' }}>actually feel.</span>
        </Headline>
        <Body t={t} size={14} color={t.mute} style={{ marginBottom: 22, maxWidth: 290 }}>{t.tagline}</Body>

        {/* trust badges row */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 22, flexWrap: 'wrap' }}>
          {['Licensed', 'LGBTQ+ safe', 'Accessible', 'Private'].map((tag, i) => (
            <div key={i} style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '6px 12px',
              background: t.surface, border: `1px solid ${t.line}`,
              borderRadius: 999,
              fontFamily: t.body, fontSize: 11, fontWeight: 500, color: t.ink, letterSpacing: 0.2,
            }}>
              <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><circle cx="5" cy="5" r="4" fill={t.accent}/><path d="M3 5l1.4 1.4L7 4" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
              {tag}
            </div>
          ))}
        </div>

        <div style={{ position: 'relative', borderRadius: t.radius, overflow: 'hidden' }}>
          <Placeholder t={t} label={IMAGES.hero} ratio="4 / 5" radius={t.radius}/>
          <div style={{
            position: 'absolute', bottom: 14, left: 14, right: 14,
            background: `${t.surface}f5`, padding: '12px 14px',
            borderRadius: t.radius - 4,
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            border: `1px solid ${t.line}`,
          }}>
            <div>
              <div style={{ fontFamily: t.mono, fontSize: 9, letterSpacing: 1, color: t.accent, textTransform: 'uppercase', whiteSpace: 'nowrap' }}>● Now booking</div>
              <div style={{ fontFamily: t.display, fontSize: 14, fontWeight: 500, color: t.ink, marginTop: 3 }}>Free 15-min consult</div>
            </div>
          </div>
        </div>

        <Ornament t={t} style={{ margin: '28px auto 20px', justifyContent: 'center' }}/>
        <TButton t={t} full onClick={onBook}>Book your consultation</TButton>
      </div>
    );
  }

  if (t.id === 'earth') {
    return (
      <div style={{ background: t.bg, padding: '28px 20px 32px' }}>
        <Kicker t={t} style={{ marginBottom: 16 }}>A small studio · since 2017</Kicker>
        <Headline t={t} size={44} style={{ marginBottom: 12 }}>
          Slow beauty,<br/>
          <span style={{ color: t.accent, fontStyle: 'italic' }}>grounded.</span>
        </Headline>
        <Body t={t} size={13} color={t.mute} style={{ marginBottom: 20 }}>{t.tagline}</Body>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 8 }}>
          <Placeholder t={t} label={IMAGES.hero} ratio="3 / 4"/>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <Placeholder t={t} label={IMAGES.studio2} ratio="1 / 1"/>
            <Placeholder t={t} label={IMAGES.studio1} ratio="1 / 1"/>
          </div>
        </div>
        <Ornament t={t} style={{ margin: '24px auto' }}/>
        <TButton t={t} full onClick={onBook}>Book a treatment</TButton>
      </div>
    );
  }

  if (t.id === 'minimal') {
    return (
      <div style={{ background: t.bg, padding: '60px 28px 40px' }}>
        <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 2, color: t.mute, marginBottom: 48 }}>001 — BLANC</div>
        <Headline t={t} size={44} italic style={{ marginBottom: 8 }}>Nails.</Headline>
        <Headline t={t} size={44} style={{ marginBottom: 32, fontFamily: t.body, fontWeight: 300 }}>Quietly considered.</Headline>
        <Placeholder t={t} label={IMAGES.hero} ratio="4 / 5"/>
        <div style={{ marginTop: 32, fontFamily: t.body, fontSize: 13, lineHeight: 1.7, color: t.ink }}>{t.tagline}</div>
        <div style={{ marginTop: 32 }}>
          <TButton t={t} full onClick={onBook}>Book</TButton>
        </div>
      </div>
    );
  }

  if (t.id === 'kawaii') {
    return (
      <div style={{ background: `linear-gradient(180deg, ${t.accent2}44 0%, ${t.bg} 40%)`, padding: '24px 20px 32px', position: 'relative', overflow: 'hidden' }}>
        {/* pastel cloud blobs */}
        <div style={{ position: 'absolute', top: 60, right: -30, width: 140, height: 140, background: t.accent, opacity: 0.35, borderRadius: '50% 55% 45% 55% / 55% 45% 55% 45%' }}/>
        <div style={{ position: 'absolute', top: 220, left: -30, width: 100, height: 100, background: t.accent2, opacity: 0.45, borderRadius: '55% 45% 60% 40%' }}/>
        <div style={{ position: 'absolute', top: 18, right: 26, fontSize: 16, color: t.accent }}>❀</div>
        <div style={{ position: 'absolute', top: 46, left: 20, fontSize: 12, color: t.accent2 }}>❀</div>

        <div style={{ position: 'relative', zIndex: 2, textAlign: 'center' }}>
          <Kicker t={t} style={{ justifyContent: 'center', marginBottom: 8 }}>ꕥ open & cozy ꕥ</Kicker>
          <div style={{ fontFamily: t.display, fontStyle: 'italic', fontWeight: 400, fontSize: 54, lineHeight: 0.95, letterSpacing: '-0.02em', color: t.ink }}>
            mochi<br/>
            <span style={{ color: t.accent }}>room</span>
            <span style={{ fontSize: 28, marginLeft: 4, color: t.accent2 }}>ꕥ</span>
          </div>
          <Body t={t} size={13} color={t.mute} style={{ marginTop: 14, maxWidth: 280, marginLeft: 'auto', marginRight: 'auto' }}>{t.tagline}</Body>
        </div>

        <div style={{ marginTop: 22, position: 'relative' }}>
          <div style={{ borderRadius: 32, overflow: 'hidden', border: `2px solid ${t.ink}`, boxShadow: `5px 5px 0 0 ${t.accent}` }}>
            <Placeholder t={t} label={IMAGES.hero} ratio="4 / 5" radius={30}/>
          </div>
          {/* cute floating sticker badges */}
          <div style={{ position: 'absolute', top: -12, left: -10, background: t.surface, border: `2px solid ${t.ink}`, borderRadius: 999, padding: '6px 12px', fontFamily: t.display, fontStyle: 'italic', fontSize: 13, color: t.ink, transform: 'rotate(-6deg)' }}>
            ꕥ new set!
          </div>
          <div style={{ position: 'absolute', bottom: -12, right: -8, background: t.accent, color: t.surface, border: `2px solid ${t.ink}`, borderRadius: 999, padding: '6px 12px', fontFamily: t.display, fontStyle: 'italic', fontSize: 13, transform: 'rotate(5deg)' }}>
            so cute ✿
          </div>
        </div>

        {/* two little pastel tiles */}
        <div style={{ marginTop: 22, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div style={{ background: t.surface, border: `1.5px solid ${t.ink}`, borderRadius: 22, padding: '12px 14px', boxShadow: `3px 3px 0 0 ${t.accent2}` }}>
            <div style={{ fontFamily: t.mono, fontSize: 9, letterSpacing: 1.2, color: t.mute, textTransform: 'uppercase' }}>★ rating</div>
            <div style={{ fontFamily: t.display, fontStyle: 'italic', fontSize: 22, color: t.ink, marginTop: 2 }}>4.9 / 5</div>
          </div>
          <div style={{ background: t.surface, border: `1.5px solid ${t.ink}`, borderRadius: 22, padding: '12px 14px', boxShadow: `3px 3px 0 0 ${t.accent}` }}>
            <div style={{ fontFamily: t.mono, fontSize: 9, letterSpacing: 1.2, color: t.mute, textTransform: 'uppercase' }}>♡ clients</div>
            <div style={{ fontFamily: t.display, fontStyle: 'italic', fontSize: 22, color: t.ink, marginTop: 2 }}>2,400+</div>
          </div>
        </div>

        <div style={{ marginTop: 22 }}>
          <TButton t={t} full onClick={onBook} variant="primary">ꕥ book your cute time ꕥ</TButton>
        </div>
      </div>
    );
  }

  if (t.id === 'laveo') {
    return (
      <div style={{ background: t.bg, padding: '28px 20px 32px' }}>
        {/* centered masthead */}
        <div style={{ textAlign: 'center', marginBottom: 22 }}>
          <div style={{ width: 72, height: 72, borderRadius: 999, margin: '0 auto 14px', overflow: 'hidden', border: `1px solid ${t.line}` }}>
            <Placeholder t={t} label={IMAGES.portrait} ratio="1 / 1" radius={999}/>
          </div>
          <div style={{ fontFamily: t.display, fontWeight: t.displayWeight, fontStyle: 'italic', fontSize: 42, color: t.ink, letterSpacing: '-0.02em', lineHeight: 1 }}>laveom</div>
          <div style={{ fontFamily: t.mono, fontSize: 9, letterSpacing: 3, color: t.accent, textTransform: 'uppercase', marginTop: 6 }}>— studio —</div>
          <Body t={t} size={13} color={t.mute} style={{ marginTop: 14, maxWidth: 270, marginLeft: 'auto', marginRight: 'auto' }}>{t.tagline}</Body>
        </div>

        {/* hero image */}
        <Placeholder t={t} label={IMAGES.hero} ratio="5 / 4" radius={t.radius}/>

        {/* link-in-bio style tile grid */}
        <div style={{ marginTop: 18, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {[
            { label: 'Book a treatment', sub: 'Now — June', primary: true, action: () => onBook() },
            { label: 'Brow menu', sub: 'Shapes & tints', bg: t.accent2 + '33' },
            { label: 'Skin consult', sub: 'Free 15 min', bg: t.accent + '26' },
            { label: 'Gift cards', sub: 'Starting $50', bg: t.surface },
            { label: 'New client guide', sub: 'What to expect', bg: t.surface, wide: true },
          ].map((tile, i) => (
            <button key={i} onClick={tile.action || (() => onBook())} style={{
              gridColumn: tile.wide ? '1 / span 2' : 'auto',
              textAlign: 'left', cursor: 'pointer', border: 'none',
              background: tile.primary ? t.ink : (tile.bg || t.surface),
              color: tile.primary ? t.bg : t.ink,
              borderRadius: t.radius,
              padding: '16px 16px',
              display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
              minHeight: tile.wide ? 64 : 82,
              position: 'relative',
              border: tile.primary ? 'none' : `1px solid ${t.line}`,
            }}>
              <div style={{ fontFamily: t.mono, fontSize: 9, letterSpacing: 1.5, textTransform: 'uppercase', opacity: 0.7 }}>{tile.sub}</div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 }}>
                <div style={{ fontFamily: t.display, fontStyle: 'italic', fontSize: 18, fontWeight: t.displayWeight, letterSpacing: '-0.01em' }}>{tile.label}</div>
                <div style={{ fontSize: 14, opacity: 0.8 }}>→</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }


  return (
    <div style={{ background: t.bg, padding: '24px 22px 36px' }}>
      <Kicker t={t} style={{ marginBottom: 14 }}>A ritual studio</Kicker>
      <Headline t={t} size={46} italic style={{ marginBottom: 14, letterSpacing: '-0.02em' }}>
        Aura<span style={{ color: t.accent2 }}> & </span>Oak
      </Headline>
      <Body t={t} size={14} color={t.mute} style={{ marginBottom: 22, maxWidth: 280 }}>{t.tagline}</Body>
      <div style={{ position: 'relative' }}>
        <Placeholder t={t} label={IMAGES.hero} ratio="4 / 5" radius={t.radius}/>
        <div style={{
          position: 'absolute', bottom: 14, left: 14, right: 14,
          background: `${t.surface}f5`, padding: '10px 14px',
          borderRadius: t.radius - 4,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div>
            <div style={{ fontFamily: t.mono, fontSize: 9, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase' }}>Now booking</div>
            <div style={{ fontFamily: t.display, fontSize: 14, fontWeight: 500, color: t.ink, marginTop: 2 }}>Spring rituals</div>
          </div>
          <div style={{ fontFamily: t.body, fontSize: 12, color: t.accent2, fontStyle: 'italic' }}>→</div>
        </div>
      </div>
      <Ornament t={t} style={{ margin: '28px auto 20px' }}/>
      <TButton t={t} full onClick={onBook}>Book a session</TButton>
    </div>
  );
}

// ── Quick-stats strip ──
function StatStrip({ t }) {
  const stats = [
    { k: '4.9', l: 'rating' },
    { k: '320+', l: 'reviews' },
    { k: '9 yrs', l: 'practice' },
  ];
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
      borderTop: `1px solid ${t.line}`, borderBottom: `1px solid ${t.line}`,
      background: t.surface,
    }}>
      {stats.map((s, i) => (
        <div key={i} style={{
          padding: '14px 10px', textAlign: 'center',
          borderRight: i < 2 ? `1px solid ${t.line}` : 'none',
        }}>
          <div style={{
            fontFamily: t.display, fontSize: 20,
            fontWeight: t.displayWeight, color: t.ink,
            letterSpacing: `${t.displayTracking}em`,
          }}>{s.k}</div>
          <div style={{ fontFamily: t.mono, fontSize: 9, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase', marginTop: 2 }}>{s.l}</div>
        </div>
      ))}
    </div>
  );
}

// ── About / Meet the Specialist ──
function AboutSection({ t }) {
  return (
    <section style={{ padding: '32px 22px', background: t.bg }}>
      <Kicker t={t} style={{ marginBottom: 10 }}>Meet the specialist</Kicker>
      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start', marginTop: 8 }}>
        <div style={{ width: 82, flexShrink: 0 }}>
          <Placeholder t={t} label={IMAGES.portrait} ratio="1 / 1" radius={t.id === 'y2k' ? 999 : t.radius}/>
        </div>
        <div style={{ flex: 1 }}>
          <Headline t={t} size={20} italic={t.id === 'aura' || t.id === 'luxe'}>{t.specialist}</Headline>
          <Body t={t} size={13} color={t.mute} style={{ marginTop: 8 }}>{t.bio}</Body>
        </div>
      </div>
    </section>
  );
}

// ── Services list ──
function ServicesSection({ t, onSelect }) {
  return (
    <section style={{ padding: '8px 22px 32px', background: t.bg }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 16 }}>
        <Headline t={t} size={28} italic={t.id === 'aura'}>Services</Headline>
        <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase' }}>{SERVICES.length} offered</div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: t.id === 'bold' ? 10 : 0 }}>
        {SERVICES.map((s, i) => (
          <ServiceRow key={s.id} t={t} s={s} onClick={() => onSelect(s)} last={i === SERVICES.length - 1}/>
        ))}
      </div>
    </section>
  );
}

function ServiceRow({ t, s, onClick, last }) {
  const isBlock = t.id === 'bold';
  const isStreet = t.id === 'street';
  const isY2k = t.id === 'y2k';
  const isGraf = t.id === 'graffiti';
  const isKawaii = t.id === 'kawaii';

  if (isKawaii) {
    const tints = [t.accent + '40', t.accent2 + '55', t.surface, t.accent + '30'];
    return (
      <button onClick={onClick} style={{
        textAlign: 'left', cursor: 'pointer',
        background: tints[SERVICES.indexOf(s) % 4],
        border: `1.5px solid ${t.ink}`,
        borderRadius: 22,
        padding: '14px 16px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 10, boxShadow: `3px 3px 0 0 ${t.ink}`,
      }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontFamily: t.display, fontStyle: 'italic', fontSize: 17, color: t.ink, lineHeight: 1.1 }}>{s.name}</div>
          <div style={{ fontFamily: t.mono, fontSize: 10, color: t.mute, marginTop: 4, letterSpacing: 1 }}>{s.duration} min ꕥ sooo cute</div>
        </div>
        <div style={{ background: t.ink, color: t.bg, padding: '6px 12px', borderRadius: 999, fontFamily: t.display, fontStyle: 'italic', fontSize: 15 }}>${s.price}</div>
      </button>
    );
  }

  if (isGraf) {
    const idx = SERVICES.indexOf(s);
    const rotations = ['-1deg', '1deg', '-0.6deg', '0.8deg'];
    const tints = [t.accent, t.accent2, t.surface, t.accent];
    return (
      <button onClick={onClick} style={{
        textAlign: 'left', cursor: 'pointer',
        background: tints[idx % 4],
        color: tints[idx % 4] === t.surface ? t.accent2 : t.ink,
        border: `2.5px solid ${t.ink}`,
        padding: '14px 16px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        transform: `rotate(${rotations[idx % 4]})`,
        marginBottom: 12, boxShadow: `4px 4px 0 0 ${t.ink}`,
      }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontFamily: t.display, fontSize: 15, color: t.ink, textTransform: 'uppercase', letterSpacing: 0.5, lineHeight: 1.05 }}>{s.name}</div>
          <div style={{ fontFamily: t.mono, fontSize: 10, color: t.ink, opacity: 0.7, marginTop: 4, letterSpacing: 1 }}>{s.duration} MIN</div>
        </div>
        <div style={{ background: t.ink, color: tints[idx % 4], padding: '6px 10px', fontFamily: t.display, fontSize: 15 }}>${s.price}</div>
      </button>
    );
  }

  if (isBlock) {
    return (
      <button onClick={onClick} style={{
        textAlign: 'left', border: 'none', background: t.surface,
        padding: '18px 16px', borderRadius: 8, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10,
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: t.display, fontWeight: 900, fontSize: 17, color: t.ink, letterSpacing: '-0.02em', textTransform: 'uppercase', lineHeight: 1.1 }}>{s.name}</div>
          <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1, color: t.mute, textTransform: 'uppercase', marginTop: 6 }}>{s.duration} MIN</div>
        </div>
        <div style={{ background: t.accent, color: t.ink, padding: '8px 12px', fontFamily: t.display, fontWeight: 900, fontSize: 16 }}>${s.price}</div>
      </button>
    );
  }

  if (isStreet) {
    return (
      <button onClick={onClick} style={{
        textAlign: 'left', border: 'none', background: 'transparent',
        padding: '16px 0', cursor: 'pointer',
        borderBottom: `1px solid ${t.line}`,
        display: 'grid', gridTemplateColumns: '28px 1fr auto', gap: 12, alignItems: 'center',
      }}>
        <div style={{ fontFamily: t.mono, fontSize: 10, color: t.accent, letterSpacing: 1 }}>{String(SERVICES.indexOf(s)+1).padStart(2,'0')}</div>
        <div>
          <div style={{ fontFamily: t.display, fontWeight: 700, fontSize: 15, color: t.ink, textTransform: 'uppercase', letterSpacing: 0.5, lineHeight: 1.2 }}>{s.name}</div>
          <div style={{ fontFamily: t.mono, fontSize: 10, color: t.mute, marginTop: 4, letterSpacing: 1 }}>{s.duration}_MIN · ${s.price}.00</div>
        </div>
        <div style={{ fontFamily: t.mono, color: t.accent, fontSize: 14 }}>▸</div>
      </button>
    );
  }

  if (isY2k) {
    return (
      <button onClick={onClick} style={{
        textAlign: 'left', border: `2px solid ${t.ink}`, background: t.surface,
        padding: '14px 16px', borderRadius: 22, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        boxShadow: `3px 3px 0 0 ${t.accent2}`, marginBottom: 10,
      }}>
        <div>
          <div style={{ fontFamily: t.display, fontWeight: 900, fontSize: 16, color: t.ink, lineHeight: 1.1 }}>{s.name}</div>
          <div style={{ fontFamily: t.body, fontSize: 12, color: t.mute, marginTop: 2 }}>{s.duration} min · so cute</div>
        </div>
        <div style={{ background: t.accent, color: t.surface, padding: '6px 12px', borderRadius: 999, fontFamily: t.display, fontWeight: 900, fontSize: 15 }}>${s.price}</div>
      </button>
    );
  }

  // aura / luxe / earth / minimal — editorial list
  return (
    <button onClick={onClick} style={{
      textAlign: 'left', border: 'none', background: 'transparent',
      padding: '18px 0', cursor: 'pointer',
      borderBottom: last ? 'none' : `1px solid ${t.line}`,
      display: 'grid', gridTemplateColumns: '1fr auto', gap: 12, alignItems: 'flex-start',
    }}>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontFamily: t.display, fontWeight: t.displayWeight, fontSize: 17, color: t.ink, letterSpacing: `${t.displayTracking}em`, lineHeight: 1.2 }}>{s.name}</div>
        <div style={{ fontFamily: t.body, fontSize: 12, color: t.mute, marginTop: 6, lineHeight: 1.5 }}>{s.desc}</div>
        <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase', marginTop: 8 }}>{s.duration} min</div>
      </div>
      <div style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
        <div style={{ fontFamily: t.display, fontWeight: t.displayWeight, fontSize: 18, color: t.ink }}>${s.price}</div>
        <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.accent2 || t.accent, textTransform: 'uppercase', marginTop: 4 }}>book →</div>
      </div>
    </button>
  );
}

// ── Gallery ──
function GallerySection({ t }) {
  const items = [IMAGES.result1, IMAGES.result2, IMAGES.result3, IMAGES.result4, IMAGES.studio1, IMAGES.product];
  return (
    <section style={{ padding: '32px 22px', background: t.surface }}>
      <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 18 }}>
        <Headline t={t} size={28} italic={t.id==='aura'}>Portfolio</Headline>
        <Kicker t={t}>recent work</Kicker>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {items.map((label, i) => (
          <Placeholder key={i} t={t} label={label} ratio={i === 0 || i === 3 ? '3 / 4' : '1 / 1'}/>
        ))}
      </div>
    </section>
  );
}

// ── Reviews ──
function ReviewsSection({ t }) {
  return (
    <section style={{ padding: '32px 22px', background: t.bg }}>
      <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 18 }}>
        <Headline t={t} size={28} italic={t.id==='aura'}>What clients say</Headline>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <StarRow t={t} n={5} size={11}/>
          <div style={{ fontFamily: t.mono, fontSize: 10, color: t.mute, letterSpacing: 1 }}>4.9</div>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {REVIEWS.map((r, i) => (
          <div key={i} style={{
            background: t.surface,
            borderRadius: t.radius,
            padding: '16px 18px',
            border: t.id === 'street' || t.id === 'bold' ? `1px solid ${t.line}` : 'none',
            boxShadow: t.id === 'y2k' ? `3px 3px 0 0 ${t.accent2}` : 'none',
          }}>
            <StarRow t={t} n={r.stars} size={11}/>
            <Body t={t} size={13} style={{ marginTop: 10, fontStyle: t.id === 'aura' || t.id === 'luxe' ? 'italic' : 'normal' }}>
              "{r.body}"
            </Body>
            <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase', marginTop: 10 }}>— {r.name}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ── Hours ──
function HoursSection({ t }) {
  return (
    <section style={{ padding: '32px 22px', background: t.surface, borderTop: `1px solid ${t.line}`, borderBottom: `1px solid ${t.line}` }}>
      <Kicker t={t} style={{ marginBottom: 12 }}>Studio hours</Kicker>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {HOURS.map((h, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: t.body, fontSize: 14, color: t.ink }}>
            <span>{h.day}</span>
            <span style={{ fontFamily: t.mono, fontSize: 12, color: h.open === 'closed' ? t.mute : t.ink, letterSpacing: 1 }}>
              {h.open === 'closed' ? 'closed' : `${h.open} — ${h.close}`}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}

// ── Policies ──
function PoliciesSection({ t }) {
  return (
    <section style={{ padding: '32px 22px', background: t.bg }}>
      <Headline t={t} size={22} italic={t.id==='aura'} style={{ marginBottom: 16 }}>Booking & policies</Headline>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {POLICIES.map((p, i) => (
          <div key={i}>
            <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.accent2 || t.accent, textTransform: 'uppercase', marginBottom: 4 }}>{p.title}</div>
            <Body t={t} size={13} color={t.mute}>{p.body}</Body>
          </div>
        ))}
      </div>
    </section>
  );
}

// ── Instagram grid ──
function InstagramSection({ t }) {
  const items = [IMAGES.ig1, IMAGES.ig2, IMAGES.ig3, IMAGES.ig4, IMAGES.ig5, IMAGES.ig6];
  return (
    <section style={{ padding: '32px 22px', background: t.surface }}>
      <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 16 }}>
        <div>
          <Kicker t={t} style={{ marginBottom: 4 }}>Instagram</Kicker>
          <Headline t={t} size={20} italic={t.id==='aura'}>@{t.business.toLowerCase().replace(/[^a-z0-9]/g,'')}</Headline>
        </div>
        <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase' }}>follow →</div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 3 }}>
        {items.map((label, i) => (
          <Placeholder key={i} t={t} label={label} ratio="1 / 1" radius={0}/>
        ))}
      </div>
    </section>
  );
}

// ── Contact / Location ──
function ContactSection({ t }) {
  return (
    <section style={{ padding: '32px 22px 24px', background: t.bg, textAlign: 'center' }}>
      <Ornament t={t} style={{ margin: '0 auto 18px' }}/>
      <Kicker t={t} style={{ justifyContent: 'center', marginBottom: 10 }}>Find the studio</Kicker>
      <Body t={t} size={14} style={{ maxWidth: 260, margin: '0 auto' }}>{t.location}</Body>
      <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
        <TButton t={t} full variant="ghost">Directions</TButton>
        <TButton t={t} full variant="ghost">Message</TButton>
      </div>
    </section>
  );
}

// ── Footer ──
function Footer({ t }) {
  return (
    <div style={{ padding: '28px 22px 36px', background: t.surface, textAlign: 'center' }}>
      <div style={{ fontFamily: t.display, fontWeight: t.displayWeight, fontSize: 18, color: t.ink, letterSpacing: `${t.displayTracking}em` }}>{t.business}</div>
      <div style={{ fontFamily: t.mono, fontSize: 10, color: t.mute, letterSpacing: 1.5, textTransform: 'uppercase', marginTop: 6 }}>© 2026 · all rituals reserved</div>
    </div>
  );
}

// ── Sticky "Book now" bar ──
function StickyBookBar({ t, onBook, visible }) {
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 20,
      padding: '12px 16px calc(12px + env(safe-area-inset-bottom))',
      background: `${t.bg}f2`,
      backdropFilter: 'blur(16px)',
      borderTop: `1px solid ${t.line}`,
      transform: visible ? 'translateY(0)' : 'translateY(100%)',
      transition: 'transform .3s ease',
      paddingBottom: 32,
    }}>
      <TButton t={t} full onClick={onBook} variant="primary">
        {t.id === 'street' ? '▸ BOOK THE CHAIR' :
         t.id === 'bold'   ? 'BOOK NOW →' :
         t.id === 'y2k'    ? '☆ book me bestie ☆' :
         t.id === 'luxe'   ? 'Request Appointment' :
         'Book a session'}
      </TButton>
    </div>
  );
}

// ── Landing: whole scroll page ──
function Landing({ t, onBook }) {
  const [scrolled, setScrolled] = useStateS(false);
  const scrollRef = React.useRef(null);
  useEffectS(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => setScrolled(el.scrollTop > 200);
    el.addEventListener('scroll', onScroll);
    return () => el.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div ref={scrollRef} className="phone-scroll" style={{
      height: '100%', overflowY: 'auto', background: t.bg, position: 'relative',
      animation: 'fadeIn .3s ease',
    }}>
      <TopBar t={t}/>
      <Hero t={t} onBook={onBook}/>
      <StatStrip t={t}/>
      <AboutSection t={t}/>
      <ServicesSection t={t} onSelect={onBook}/>
      <GallerySection t={t}/>
      <ReviewsSection t={t}/>
      <HoursSection t={t}/>
      <PoliciesSection t={t}/>
      <InstagramSection t={t}/>
      <ContactSection t={t}/>
      <Footer t={t}/>
      <div style={{ height: 100 }}/>
      <StickyBookBar t={t} onBook={() => onBook()} visible={scrolled}/>
    </div>
  );
}

Object.assign(window, { Landing });
