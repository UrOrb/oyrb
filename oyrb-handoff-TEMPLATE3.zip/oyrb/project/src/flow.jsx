// Booking flow: service picked → date → time → add-ons → review → confirmation
// Presented as a modal sheet that slides up over the landing page.

const { useState: uSf, useMemo: uMf, useEffect: uEf } = React;

// ── Progress dots ──
function Progress({ t, step, total }) {
  return (
    <div style={{ display: 'flex', gap: 6, justifyContent: 'center', padding: '14px 0 6px' }}>
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} style={{
          width: i === step ? 24 : 6, height: 6, borderRadius: 3,
          background: i <= step ? (t.accent) : t.line,
          transition: 'width .3s ease, background .3s ease',
        }}/>
      ))}
    </div>
  );
}

// ── Calendar ──
function Calendar({ t, value, onChange }) {
  const today = new Date();
  today.setHours(0,0,0,0);
  const [month, setMonth] = uSf(() => new Date(today.getFullYear(), today.getMonth(), 1));

  const year = month.getFullYear();
  const m = month.getMonth();
  const first = new Date(year, m, 1);
  const startDay = first.getDay(); // 0=Sun
  const daysInMonth = new Date(year, m + 1, 0).getDate();

  const monthName = month.toLocaleString('en', { month: 'long' });
  const dayNames = ['S','M','T','W','T','F','S'];

  const cells = [];
  for (let i = 0; i < startDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, m, d));

  const sameDay = (a, b) => a && b && a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate();

  return (
    <div style={{ padding: '8px 4px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 4px 14px' }}>
        <button onClick={() => setMonth(new Date(year, m - 1, 1))} style={navBtn(t)}>‹</button>
        <div style={{ fontFamily: t.display, fontWeight: t.displayWeight, fontSize: 18, color: t.ink, letterSpacing: `${t.displayTracking}em`, textTransform: t.id==='street'?'uppercase':'none' }}>
          {monthName} {year}
        </div>
        <button onClick={() => setMonth(new Date(year, m + 1, 1))} style={navBtn(t)}>›</button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2 }}>
        {dayNames.map((d, i) => (
          <div key={i} style={{
            textAlign: 'center', fontFamily: t.mono, fontSize: 10,
            color: t.mute, letterSpacing: 1, padding: '4px 0 8px',
          }}>{d}</div>
        ))}
        {cells.map((date, i) => {
          if (!date) return <div key={i}/>;
          const past = date < today;
          const selected = sameDay(date, value);
          const isDisabled = past || date.getDay() === 1 || date.getDay() === 0; // closed mon/sun
          return (
            <button key={i} disabled={isDisabled} onClick={() => onChange(date)} style={{
              aspectRatio: '1 / 1',
              border: 'none', cursor: isDisabled ? 'not-allowed' : 'pointer',
              background: selected ? t.accent : 'transparent',
              color: selected ? (t.id === 'luxe' ? t.bg : (t.id === 'y2k' ? t.surface : t.ink)) : (isDisabled ? t.mute : t.ink),
              opacity: isDisabled ? 0.3 : 1,
              fontFamily: t.body, fontSize: 14,
              fontWeight: selected ? 600 : 400,
              borderRadius: t.id === 'bold' ? 4 : t.id === 'minimal' || t.id === 'street' ? 0 : 999,
              transition: 'background .15s ease',
            }}>
              {date.getDate()}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function navBtn(t) {
  return {
    width: 36, height: 36, borderRadius: t.radiusBtn,
    background: t.surface, border: `1px solid ${t.line}`, cursor: 'pointer',
    fontFamily: t.body, fontSize: 18, color: t.ink,
  };
}

// ── Time slots ──
const TIME_SLOTS = ['10:00', '10:45', '11:30', '13:00', '14:00', '15:30', '16:15', '17:00'];

function TimeGrid({ t, value, onChange, date }) {
  // pseudo-random disable based on date to feel real
  const disabled = uMf(() => {
    if (!date) return new Set();
    const seed = date.getDate();
    return new Set(TIME_SLOTS.filter((_, i) => ((i + seed) % 5 === 0)));
  }, [date]);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
      {TIME_SLOTS.map(slot => {
        const isDisabled = disabled.has(slot);
        const selected = value === slot;
        return (
          <button key={slot} disabled={isDisabled} onClick={() => onChange(slot)} style={{
            padding: '14px 0',
            border: `1px solid ${selected ? t.accent : t.line}`,
            background: selected ? t.accent : (isDisabled ? 'transparent' : t.surface),
            color: selected ? (t.id === 'luxe' ? t.bg : (t.id === 'y2k' ? t.surface : t.ink)) : (isDisabled ? t.mute : t.ink),
            fontFamily: t.body, fontSize: 15,
            fontWeight: selected ? 600 : 400,
            borderRadius: t.radius,
            opacity: isDisabled ? 0.4 : 1,
            cursor: isDisabled ? 'not-allowed' : 'pointer',
            textDecoration: isDisabled ? 'line-through' : 'none',
          }}>
            {slot}
          </button>
        );
      })}
    </div>
  );
}

// ── Step 1: Date + Time ──
function StepDateTime({ t, service, date, time, onDate, onTime, onNext }) {
  return (
    <div style={{ padding: '16px 22px 32px' }}>
      <Kicker t={t} style={{ marginBottom: 10 }}>Step 01 · Schedule</Kicker>
      <Headline t={t} size={28} italic={t.id === 'aura'} style={{ marginBottom: 6 }}>Choose a date & time</Headline>
      <Body t={t} size={13} color={t.mute} style={{ marginBottom: 18 }}>
        For <strong style={{ color: t.ink }}>{service.name}</strong> · {service.duration} min
      </Body>
      <div style={{
        background: t.surface, borderRadius: t.radius,
        padding: 10, border: `1px solid ${t.line}`,
      }}>
        <Calendar t={t} value={date} onChange={onDate}/>
      </div>

      {date && (
        <div style={{ marginTop: 22, animation: 'fadeUp .3s ease' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
            <Headline t={t} size={18} italic={t.id==='aura'}>Available times</Headline>
            <div style={{ fontFamily: t.mono, fontSize: 10, color: t.mute, letterSpacing: 1.5, textTransform: 'uppercase' }}>
              {date.toLocaleDateString('en', { weekday: 'long', month: 'short', day: 'numeric' })}
            </div>
          </div>
          <TimeGrid t={t} value={time} onChange={onTime} date={date}/>
        </div>
      )}

      <div style={{ marginTop: 28 }}>
        <TButton t={t} full onClick={onNext} disabled={!date || !time}>Continue →</TButton>
      </div>
    </div>
  );
}

// ── Step 2: Add-ons ──
function StepAddons({ t, addons, onToggle, onNext, onBack }) {
  return (
    <div style={{ padding: '16px 22px 32px' }}>
      <Kicker t={t} style={{ marginBottom: 10 }}>Step 02 · Upgrade</Kicker>
      <Headline t={t} size={28} italic={t.id === 'aura'} style={{ marginBottom: 6 }}>Add a little more</Headline>
      <Body t={t} size={13} color={t.mute} style={{ marginBottom: 20 }}>
        Optional pairings to your ritual. Tap to add or remove.
      </Body>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {ADDONS.map(a => {
          const active = addons.includes(a.id);
          return (
            <button key={a.id} onClick={() => onToggle(a.id)} style={{
              textAlign: 'left', cursor: 'pointer',
              background: active ? (t.id === 'luxe' ? t.accent + '22' : t.accent + '1a') : t.surface,
              border: `1px solid ${active ? t.accent : t.line}`,
              borderRadius: t.radius,
              padding: '14px 16px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
              transition: 'all .2s ease',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{
                  width: 22, height: 22, borderRadius: t.id === 'bold' || t.id === 'street' || t.id === 'minimal' ? 4 : 999,
                  border: `1.5px solid ${active ? t.accent : t.mute}`,
                  background: active ? t.accent : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  {active && <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke={t.id === 'luxe' ? t.bg : (t.id === 'y2k' ? t.surface : t.ink)} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 6l3 3 5-6"/></svg>}
                </div>
                <div>
                  <div style={{ fontFamily: t.body, fontSize: 14, fontWeight: 500, color: t.ink }}>{a.name}</div>
                  <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1, color: t.mute, textTransform: 'uppercase', marginTop: 2 }}>optional</div>
                </div>
              </div>
              <div style={{ fontFamily: t.display, fontWeight: t.displayWeight, fontSize: 16, color: t.ink }}>+${a.price}</div>
            </button>
          );
        })}
      </div>
      <div style={{ marginTop: 28, display: 'flex', gap: 10 }}>
        <TButton t={t} onClick={onBack} variant="ghost">← Back</TButton>
        <TButton t={t} full onClick={onNext}>Continue →</TButton>
      </div>
    </div>
  );
}

// ── Step 3: Review + Policy ──
function StepReview({ t, service, date, time, addons, policy, onPolicy, onBack, onConfirm }) {
  const addonItems = ADDONS.filter(a => addons.includes(a.id));
  const addonTotal = addonItems.reduce((s, a) => s + a.price, 0);
  const total = service.price + addonTotal;
  const deposit = Math.round(total * 0.3);

  return (
    <div style={{ padding: '16px 22px 32px' }}>
      <Kicker t={t} style={{ marginBottom: 10 }}>Step 03 · Review</Kicker>
      <Headline t={t} size={28} italic={t.id === 'aura'} style={{ marginBottom: 18 }}>Confirm your booking</Headline>

      <div style={{ background: t.surface, borderRadius: t.radius, border: `1px solid ${t.line}`, padding: '18px 18px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <ReviewRow t={t} label="Service" value={service.name} sub={`${service.duration} min`} price={`$${service.price}`}/>
        <div style={{ height: 1, background: t.line }}/>
        <ReviewRow t={t} label="When" value={date.toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric' })} sub={time}/>
        {addonItems.length > 0 && (
          <>
            <div style={{ height: 1, background: t.line }}/>
            <div>
              <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase', marginBottom: 8 }}>Add-ons</div>
              {addonItems.map(a => (
                <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: t.body, fontSize: 13, color: t.ink, padding: '4px 0' }}>
                  <span>{a.name}</span>
                  <span style={{ fontFamily: t.mono }}>+${a.price}</span>
                </div>
              ))}
            </div>
          </>
        )}
        <div style={{ height: 1, background: t.line }}/>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase' }}>Total</div>
            <div style={{ fontFamily: t.display, fontSize: 28, fontWeight: t.displayWeight, color: t.ink, letterSpacing: `${t.displayTracking}em`, marginTop: 2 }}>${total}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase' }}>Deposit due today</div>
            <div style={{ fontFamily: t.display, fontSize: 18, fontWeight: t.displayWeight, color: t.accent, marginTop: 4 }}>${deposit}</div>
            <div style={{ fontFamily: t.mono, fontSize: 9, color: t.mute, letterSpacing: 1, marginTop: 2 }}>30% · non-refundable</div>
          </div>
        </div>
      </div>

      {/* Policy agreement */}
      <button onClick={() => onPolicy(!policy)} style={{
        marginTop: 18, width: '100%',
        textAlign: 'left', cursor: 'pointer',
        background: 'transparent', border: `1px solid ${policy ? t.accent : t.line}`,
        borderRadius: t.radius, padding: '14px 16px',
        display: 'flex', alignItems: 'flex-start', gap: 12,
      }}>
        <div style={{
          width: 22, height: 22, borderRadius: t.id === 'bold' || t.id === 'street' || t.id === 'minimal' ? 4 : 6,
          border: `1.5px solid ${policy ? t.accent : t.mute}`,
          background: policy ? t.accent : 'transparent',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0, marginTop: 1,
        }}>
          {policy && <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke={t.id === 'luxe' ? t.bg : (t.id === 'y2k' ? t.surface : t.ink)} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 6l3 3 5-6"/></svg>}
        </div>
        <div>
          <div style={{ fontFamily: t.body, fontSize: 13, fontWeight: 500, color: t.ink }}>I agree to the cancellation policy</div>
          <div style={{ fontFamily: t.body, fontSize: 12, color: t.mute, marginTop: 4, lineHeight: 1.5 }}>
            48hr notice to cancel or reschedule. Inside 48hr the deposit is forfeit; same-day cancels are billed 50%.
          </div>
        </div>
      </button>

      <div style={{ marginTop: 20, display: 'flex', gap: 10 }}>
        <TButton t={t} onClick={onBack} variant="ghost">← Back</TButton>
        <TButton t={t} full onClick={onConfirm} disabled={!policy}>Pay deposit · ${deposit}</TButton>
      </div>
    </div>
  );
}

function ReviewRow({ t, label, value, sub, price }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
      <div>
        <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.mute, textTransform: 'uppercase', marginBottom: 4 }}>{label}</div>
        <div style={{ fontFamily: t.body, fontSize: 14, color: t.ink, fontWeight: 500 }}>{value}</div>
        {sub && <div style={{ fontFamily: t.mono, fontSize: 11, color: t.mute, marginTop: 2, letterSpacing: 0.5 }}>{sub}</div>}
      </div>
      {price && <div style={{ fontFamily: t.display, fontSize: 16, fontWeight: t.displayWeight, color: t.ink }}>{price}</div>}
    </div>
  );
}

// ── Step 4: Confirmation ──
function StepConfirm({ t, service, date, time, onDone }) {
  return (
    <div style={{ padding: '40px 22px 32px', textAlign: 'center', minHeight: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', animation: 'fadeUp .4s ease' }}>
      <div style={{ fontSize: 64, marginBottom: 8, color: t.accent, fontFamily: t.display }}>
        {t.id === 'y2k' ? '☆' : t.id === 'street' ? '✓' : t.id === 'bold' ? '◼' : t.id === 'earth' ? '✦' : '✻'}
      </div>
      <Kicker t={t} style={{ justifyContent: 'center', marginBottom: 10 }}>Confirmed</Kicker>
      <Headline t={t} size={32} italic={t.id === 'aura' || t.id === 'luxe'} style={{ marginBottom: 12 }}>
        {t.id === 'street' ? 'YOU\'RE LOCKED IN' :
         t.id === 'y2k'    ? 'yay bestie ♡' :
         t.id === 'bold'   ? 'BOOKED.' :
         'See you soon'}
      </Headline>
      <Body t={t} size={14} color={t.mute} style={{ maxWidth: 280, margin: '0 auto 24px' }}>
        A confirmation with studio details, parking, and pre-appointment notes is on its way to your inbox.
      </Body>

      <div style={{ background: t.surface, borderRadius: t.radius, padding: '18px 18px', border: `1px solid ${t.line}`, textAlign: 'left', margin: '0 auto', maxWidth: 320 }}>
        <div style={{ fontFamily: t.display, fontSize: 16, fontWeight: 500, color: t.ink, marginBottom: 2 }}>{service.name}</div>
        <div style={{ fontFamily: t.body, fontSize: 13, color: t.mute, marginBottom: 12 }}>{service.duration} min · with {t.specialist}</div>
        <div style={{ display: 'flex', gap: 10 }}>
          <div style={{
            width: 52, textAlign: 'center', padding: '8px 0',
            background: t.bg, borderRadius: t.radius, border: `1px solid ${t.line}`,
          }}>
            <div style={{ fontFamily: t.mono, fontSize: 9, color: t.accent, letterSpacing: 1.5 }}>{date.toLocaleString('en', { month: 'short' }).toUpperCase()}</div>
            <div style={{ fontFamily: t.display, fontWeight: t.displayWeight, fontSize: 22, color: t.ink, lineHeight: 1 }}>{date.getDate()}</div>
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <div style={{ fontFamily: t.body, fontSize: 14, color: t.ink }}>{date.toLocaleString('en', { weekday: 'long' })}</div>
            <div style={{ fontFamily: t.mono, fontSize: 12, color: t.mute, letterSpacing: 1 }}>{time}</div>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <TButton t={t} full variant="accent">+ Add to calendar</TButton>
        <TButton t={t} full variant="ghost" onClick={onDone}>Back to studio</TButton>
      </div>
    </div>
  );
}

// ── Flow container (slides up as modal) ──
function BookingFlow({ t, service, onClose }) {
  const [step, setStep] = uSf(0); // 0 date, 1 addons, 2 review, 3 confirm
  const [date, setDate] = uSf(null);
  const [time, setTime] = uSf(null);
  const [addons, setAddons] = uSf([]);
  const [policy, setPolicy] = uSf(false);

  const toggle = id => setAddons(a => a.includes(id) ? a.filter(x => x !== id) : [...a, id]);

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 30,
      background: t.bg,
      animation: 'slideUp .3s ease',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '60px 16px 14px', borderBottom: `1px solid ${t.line}`,
        background: t.bg,
      }}>
        <button onClick={step === 3 ? onClose : onClose} style={{
          width: 36, height: 36, borderRadius: t.radiusBtn,
          background: t.surface, border: `1px solid ${t.line}`, cursor: 'pointer',
          fontFamily: t.body, color: t.ink, fontSize: 16,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>✕</button>
        <div style={{ fontFamily: t.display, fontWeight: t.displayWeight, fontSize: 15, color: t.ink, letterSpacing: `${t.displayTracking}em`, textTransform: t.id==='street'?'uppercase':'none' }}>
          {step === 3 ? 'Confirmed' : 'New booking'}
        </div>
        <div style={{ width: 36 }}/>
      </div>

      {step < 3 && <Progress t={t} step={step} total={3}/>}

      <div className="phone-scroll" style={{ flex: 1, overflowY: 'auto' }}>
        {step === 0 && <StepDateTime t={t} service={service} date={date} time={time} onDate={setDate} onTime={setTime} onNext={() => setStep(1)}/>}
        {step === 1 && <StepAddons t={t} addons={addons} onToggle={toggle} onBack={() => setStep(0)} onNext={() => setStep(2)}/>}
        {step === 2 && <StepReview t={t} service={service} date={date} time={time} addons={addons} policy={policy} onPolicy={setPolicy} onBack={() => setStep(1)} onConfirm={() => setStep(3)}/>}
        {step === 3 && <StepConfirm t={t} service={service} date={date} time={time} onDone={onClose}/>}
      </div>
    </div>
  );
}

Object.assign(window, { BookingFlow });
