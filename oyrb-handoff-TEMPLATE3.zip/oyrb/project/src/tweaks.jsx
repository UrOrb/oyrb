// Tweaks panel — theme switcher with swatches
// Registers edit-mode protocol with host.

const { useState: uSt, useEffect: uEt } = React;

function TweaksPanel({ themeId, onPick, onClose, onFrame, showFrame }) {
  const themeList = Object.values(THEMES);
  return (
    <div style={{
      position: 'fixed', right: 16, bottom: 16, zIndex: 9999,
      width: 320, maxHeight: '82vh', overflow: 'hidden',
      background: '#fff', color: '#111',
      borderRadius: 16,
      boxShadow: '0 20px 60px rgba(0,0,0,0.35), 0 0 0 1px rgba(0,0,0,0.08)',
      fontFamily: 'Inter, system-ui, sans-serif',
      display: 'flex', flexDirection: 'column',
      animation: 'fadeUp .2s ease',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '14px 16px',
        borderBottom: '1px solid #eee',
      }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600 }}>Tweaks</div>
          <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>Switch templates & frame</div>
        </div>
        <button onClick={onClose} style={{
          width: 26, height: 26, borderRadius: 999,
          border: 'none', background: '#f2f2f2', cursor: 'pointer',
          fontSize: 14, color: '#555',
        }}>✕</button>
      </div>

      <div style={{ padding: '12px 16px 8px', fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: '#888' }}>Template</div>
      <div style={{ overflowY: 'auto', padding: '0 12px 12px', flex: 1 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {themeList.map(t => {
            const active = t.id === themeId;
            return (
              <button key={t.id} onClick={() => onPick(t.id)} style={{
                display: 'grid', gridTemplateColumns: '40px 1fr auto', alignItems: 'center', gap: 12,
                padding: '10px 12px',
                borderRadius: 10,
                border: active ? '1.5px solid #111' : '1px solid #eee',
                background: active ? '#fafafa' : '#fff',
                cursor: 'pointer', textAlign: 'left',
              }}>
                <div style={{ display: 'flex', flexDirection: 'column', borderRadius: 6, overflow: 'hidden', height: 40, border: '1px solid rgba(0,0,0,0.08)' }}>
                  <div style={{ flex: 1, background: t.bg }}/>
                  <div style={{ flex: 1, background: t.accent }}/>
                  <div style={{ flex: 1, background: t.ink }}/>
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#111', fontFamily: t.display }}>{t.name}</div>
                  <div style={{ fontSize: 10.5, color: '#888', marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.vibe}</div>
                </div>
                <div style={{
                  width: 14, height: 14, borderRadius: 999,
                  border: '1.5px solid ' + (active ? '#111' : '#ccc'),
                  background: active ? '#111' : '#fff',
                }}/>
              </button>
            );
          })}
        </div>

        <div style={{ marginTop: 14, padding: '10px 12px', background: '#fafafa', borderRadius: 10, border: '1px solid #eee' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600 }}>Phone frame</div>
              <div style={{ fontSize: 10.5, color: '#888', marginTop: 2 }}>Show iOS device bezel</div>
            </div>
            <button onClick={() => onFrame(!showFrame)} style={{
              width: 40, height: 22, borderRadius: 999, border: 'none',
              background: showFrame ? '#111' : '#ccc', cursor: 'pointer',
              position: 'relative', padding: 0,
            }}>
              <div style={{
                position: 'absolute', top: 2, left: showFrame ? 20 : 2,
                width: 18, height: 18, borderRadius: 999, background: '#fff',
                transition: 'left .2s ease',
              }}/>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Floating toggle button when host hasn't activated edit mode (so users can still try it)
function FloatingTweakBtn({ onClick }) {
  return (
    <button onClick={onClick} style={{
      position: 'fixed', right: 20, bottom: 20, zIndex: 9998,
      height: 44, padding: '0 18px',
      borderRadius: 999, border: 'none', cursor: 'pointer',
      background: '#111', color: '#fff',
      fontFamily: 'Inter, system-ui', fontSize: 13, fontWeight: 500, letterSpacing: 0.2,
      boxShadow: '0 10px 30px rgba(0,0,0,0.25)',
      display: 'inline-flex', alignItems: 'center', gap: 8,
    }}>
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M2 4h6M10 4h2M2 10h2M6 10h6M8 4a2 2 0 104 0 2 2 0 00-4 0zM4 10a2 2 0 104 0 2 2 0 00-4 0z"/></svg>
      Templates
    </button>
  );
}

Object.assign(window, { TweaksPanel, FloatingTweakBtn });
