// Root app — iPhone frame, landing page, booking flow, tweaks panel
const { useState: uSa, useEffect: uEa, useRef: uRa } = React;

// editable defaults — persisted via __edit_mode_set_keys
const DEFAULTS = /*EDITMODE-BEGIN*/{
  "template": "aura",
  "showFrame": true
}/*EDITMODE-END*/;

function App() {
  const [themeId, setThemeId] = uSa(() => {
    try { return localStorage.getItem('bt_theme') || DEFAULTS.template; } catch { return DEFAULTS.template; }
  });
  const [showFrame, setShowFrame] = uSa(() => {
    try { const v = localStorage.getItem('bt_frame'); return v == null ? DEFAULTS.showFrame : v === '1'; } catch { return DEFAULTS.showFrame; }
  });
  const [panelOpen, setPanelOpen] = uSa(false);
  const [booking, setBooking] = uSa(null); // service object or null
  const [scale, setScale] = uSa(1);

  const t = THEMES[themeId] || THEMES.aura;

  uEa(() => { try { localStorage.setItem('bt_theme', themeId); } catch {} }, [themeId]);
  uEa(() => { try { localStorage.setItem('bt_frame', showFrame ? '1' : '0'); } catch {} }, [showFrame]);

  // edit-mode host protocol
  uEa(() => {
    const handler = (e) => {
      const d = e.data || {};
      if (d.type === '__activate_edit_mode') setPanelOpen(true);
      if (d.type === '__deactivate_edit_mode') setPanelOpen(false);
    };
    window.addEventListener('message', handler);
    window.parent && window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  const persist = (patch) => {
    window.parent && window.parent.postMessage({ type: '__edit_mode_set_keys', edits: patch }, '*');
  };
  const pickTheme = (id) => { setThemeId(id); persist({ template: id }); };
  const toggleFrame = (v) => { setShowFrame(v); persist({ showFrame: v }); };

  // scale phone to fit viewport
  uEa(() => {
    const onResize = () => {
      const pad = 48;
      const w = window.innerWidth;
      const h = window.innerHeight;
      const targetW = showFrame ? 402 : 390;
      const targetH = showFrame ? 874 : 844;
      const s = Math.min(1, (w - pad) / targetW, (h - pad) / targetH);
      setScale(s);
    };
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [showFrame]);

  // backdrop — subtle glow in the theme's accent
  const backdrop = {
    position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none',
    background: `radial-gradient(ellipse at 30% 20%, ${t.accent}22 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, ${t.accent2 || t.accent}18 0%, transparent 55%), #0c0b0a`,
    transition: 'background .4s ease',
  };

  // Title hud (top-left)
  const hud = (
    <div style={{
      position: 'fixed', top: 20, left: 24, zIndex: 10,
      fontFamily: 'Inter, system-ui', color: '#e8e6e2',
    }}>
      <div style={{ fontSize: 11, letterSpacing: 2, textTransform: 'uppercase', opacity: 0.55 }}>Booking template</div>
      <div style={{ fontSize: 22, fontFamily: t.display, fontWeight: t.displayWeight, letterSpacing: `${t.displayTracking}em`, marginTop: 2 }}>{t.name}</div>
      <div style={{ fontSize: 11, opacity: 0.55, marginTop: 4 }}>{t.vibe}</div>
    </div>
  );

  const content = (
    <Landing t={t} onBook={(s) => setBooking(s && s.id ? s : SERVICES[0])}/>
  );

  const phone = showFrame ? (
    <IOSDevice width={402} height={874} dark={t.bg.startsWith('#0') || t.bg.startsWith('#1')}>
      <div style={{ height: '100%', position: 'relative', background: t.bg }}>
        {content}
        {booking && <BookingFlow t={t} service={booking} onClose={() => setBooking(null)}/>}
      </div>
    </IOSDevice>
  ) : (
    <div style={{
      width: 390, height: 844, borderRadius: 40, overflow: 'hidden',
      background: t.bg, position: 'relative',
      boxShadow: '0 40px 80px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.06)',
    }}>
      {content}
      {booking && <BookingFlow t={t} service={booking} onClose={() => setBooking(null)}/>}
    </div>
  );

  return (
    <>
      <div style={backdrop}/>
      {hud}
      <div style={{
        position: 'fixed', inset: 0, zIndex: 1,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        overflow: 'hidden',
      }}>
        <div style={{ transform: `scale(${scale})`, transformOrigin: 'center center' }}>
          {phone}
        </div>
      </div>

      {!panelOpen && <FloatingTweakBtn onClick={() => setPanelOpen(true)}/>}
      {panelOpen && (
        <TweaksPanel
          themeId={themeId}
          onPick={pickTheme}
          showFrame={showFrame}
          onFrame={toggleFrame}
          onClose={() => setPanelOpen(false)}
        />
      )}
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
