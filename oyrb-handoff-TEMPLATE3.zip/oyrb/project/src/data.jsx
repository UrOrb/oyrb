// Shared content data — same for every theme (per your spec)

const SERVICES = [
  { id: 'glow',   name: 'Signature Glow Facial',        duration: 60,  price: 145, desc: 'A luminosity ritual: enzyme exfoliation, lymphatic sculpt, barrier-first finish.' },
  { id: 'muse',   name: "The 'Muse' Silk Press & Treatment", duration: 120, price: 185, desc: 'Deep moisture treatment, protective blow-out, silk press with heat protection.' },
  { id: 'bridal', name: 'Bridal Consultation & Trial',  duration: 90,  price: 250, desc: 'Private trial with mood-board alignment, skin prep plan, and day-of palette.' },
  { id: 'brow',   name: 'Luxe Brow Architecture',       duration: 45,  price: 85,  desc: 'Mapping, sculpt, tint. Shape built for your face, not a trend.' },
];

const ADDONS = [
  { id: 'aroma',   name: 'Aromatherapy ritual',        price: 20 },
  { id: 'lift',    name: 'LED light therapy',          price: 35 },
  { id: 'gua',     name: 'Gua sha lift (15 min)',      price: 25 },
  { id: 'scalp',   name: 'Scalp massage & serum',      price: 18 },
];

const REVIEWS = [
  { name: 'Simone R.',   body: 'I\'ve never been treated with this much care. My skin looked lit from inside for a week.', stars: 5 },
  { name: 'Jordan K.',   body: 'Booking was easy, the studio is serene, the work is meticulous. Worth every dollar.',   stars: 5 },
  { name: 'Priya M.',    body: 'Rebooked before I left. That says it all.',                                             stars: 5 },
];

const HOURS = [
  { day: 'Tue — Thu', open: '10:00', close: '18:00' },
  { day: 'Friday',    open: '10:00', close: '20:00' },
  { day: 'Saturday',  open: '09:00', close: '17:00' },
  { day: 'Sun — Mon', open: 'closed', close: '' },
];

const POLICIES = [
  { title: 'Deposit', body: 'A 30% non-refundable deposit secures your appointment and is applied to your final total.' },
  { title: 'Cancellation', body: 'Please give 48 hours notice. Cancellations inside 48 hours forfeit the deposit; same-day cancels are billed 50%.' },
  { title: 'Late arrivals', body: 'After 15 minutes your service may be shortened or rescheduled to protect the next guest.' },
  { title: 'Guests', body: 'The studio is a small, quiet space. Please arrive alone unless otherwise arranged.' },
];

// Labeled imagery placeholders — striped SVG backgrounds with monospace descriptors
// (no handmade illustrative SVGs)
const IMAGES = {
  hero:     'hero · specialist w/ client · warm window light',
  studio1:  'studio detail · linen drape on wood',
  studio2:  'hands · gua sha stone on skin',
  result1:  'result · glass skin close-up',
  result2:  'silk press · finished hair',
  result3:  'bridal · soft glam detail',
  result4:  'brow · architectural shape',
  product:  'product flat-lay · ceramic + amber glass',
  portrait: 'portrait · specialist · neutral backdrop',
  ig1: 'IG · skin before/after',
  ig2: 'IG · studio doorway',
  ig3: 'IG · behind the scenes',
  ig4: 'IG · product detail',
  ig5: 'IG · client smile',
  ig6: 'IG · ritual tools',
};

window.SERVICES = SERVICES;
window.ADDONS = ADDONS;
window.REVIEWS = REVIEWS;
window.HOURS = HOURS;
window.POLICIES = POLICIES;
window.IMAGES = IMAGES;
