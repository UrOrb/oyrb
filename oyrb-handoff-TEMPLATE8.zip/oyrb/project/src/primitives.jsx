// Themed primitives: Placeholder, Button, Card, Kicker, Divider, StarRow
// All accept `t` (theme) and adapt to it.

const { useState, useEffect, useMemo, useRef } = React;

// ── Placeholder: striped SVG + monospace label (never hand-drawn scene) ──
function Placeholder({ t, label, ratio = '4 / 5', radius, style = {}, dark }) {
  const isDark = dark ?? (t.bg.startsWith('#0') || t.bg.startsWith('#1'));
  const stripeA = isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.035)';
  const stripeB = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.07)';
  const labelColor = isDark ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.45)';
  return (
    <div style={{
      aspectRatio: ratio,
      borderRadius: radius ?? t.radius,
      background: `repeating-linear-gradient(135deg, ${stripeA} 0 10px, ${stripeB} 10px 20px)`,
      border: `1px dashed ${isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.15)'}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 12, textAlign: 'center',
      ...style,
    }}>
      <span style={{
        fontFamily: t.mono, fontSize: 10, letterSpacing: 0.6,
        textTransform: 'uppercase', color: labelColor, lineHeight: 1.4,
      }}>{label}</span>
    </div>
  );
}

// ── Themed button ──
function TButton({ t, children, onClick, variant = 'primary', full, style = {}, disabled }) {
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    height: 52, padding: '0 24px',
    borderRadius: t.radiusBtn,
    fontFamily: t.id === 'bold' || t.id === 'street' ? t.display : t.body,
    fontWeight: t.id === 'bold' ? 900 : t.id === 'street' ? 700 : 500,
    fontSize: t.id === 'bold' ? 15 : 14,
    letterSpacing: t.id === 'street' || t.id === 'bold' ? 0.08 : 0.02,
    textTransform: t.id === 'street' || t.id === 'bold' ? 'uppercase' : 'none',
    border: 'none', cursor: disabled ? 'not-allowed' : 'pointer',
    width: full ? '100%' : 'auto',
    transition: 'transform .15s ease, opacity .15s ease',
    opacity: disabled ? 0.4 : 1,
  };
  const fills = {
    primary: { background: t.btnFill, color: t.btnText },
    ghost:   { background: 'transparent', color: t.ink, border: `1px solid ${t.line}` },
    accent:  { background: t.accent, color: t.id === 'luxe' ? t.bg : (t.id === 'y2k' ? t.surface : t.ink) },
  };
  return (
    <button disabled={disabled} onClick={onClick}
      onMouseDown={e => e.currentTarget.style.transform = 'scale(0.98)'}
      onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
      onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
      style={{ ...base, ...fills[variant], ...style }}>
      {children}
    </button>
  );
}

// ── Kicker (small eyebrow text) ──
function Kicker({ t, children, style = {} }) {
  if (!children && !t.kicker) return null;
  return (
    <div style={{
      fontFamily: t.mono,
      fontSize: 10, letterSpacing: 2,
      textTransform: 'uppercase',
      color: t.mute,
      display: 'flex', alignItems: 'center', gap: 8,
      ...style,
    }}>
      {t.kicker && <span style={{ color: t.accent }}>{t.kicker}</span>}
      {children}
    </div>
  );
}

// ── Divider: theme-specific ornament ──
function Ornament({ t, style = {} }) {
  const s = { color: t.mute, ...style };
  if (t.ornament === 'arc') return (
    <svg viewBox="0 0 80 12" width="80" height="12" style={s}>
      <path d="M2 10 Q 40 -4 78 10" fill="none" stroke={t.accent2} strokeWidth="1.2"/>
    </svg>
  );
  if (t.ornament === 'rule') return (
    <div style={{ display:'flex', alignItems:'center', gap: 8, ...style }}>
      <div style={{ width: 24, height: 1, background: t.accent }}/>
      <div style={{ width: 4, height: 4, background: t.accent, transform: 'rotate(45deg)' }}/>
      <div style={{ width: 24, height: 1, background: t.accent }}/>
    </div>
  );
  if (t.ornament === 'sprig') return (
    <svg viewBox="0 0 60 12" width="60" height="12" style={s}>
      <line x1="30" y1="0" x2="30" y2="12" stroke={t.accent2} strokeWidth="1"/>
      <path d="M30 4 L 22 0 M30 6 L 20 4 M30 8 L 22 10" stroke={t.accent2} strokeWidth="1" fill="none" strokeLinecap="round"/>
      <path d="M30 4 L 38 0 M30 6 L 40 4 M30 8 L 38 10" stroke={t.accent2} strokeWidth="1" fill="none" strokeLinecap="round"/>
    </svg>
  );
  if (t.ornament === 'block') return (
    <div style={{ display:'flex', gap: 4, ...style }}>
      <div style={{ width: 12, height: 12, background: t.accent }}/>
      <div style={{ width: 12, height: 12, background: t.accent2 }}/>
      <div style={{ width: 12, height: 12, background: t.ink }}/>
    </div>
  );
  if (t.ornament === 'tag') return (
    <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1, color: t.accent, ...style }}>
      ▞▞ EOF ▞▞
    </div>
  );
  if (t.ornament === 'sparkle') return (
    <div style={{ fontSize: 14, color: t.accent, letterSpacing: 4, ...style }}>★ ✦ ★</div>
  );
  if (t.ornament === 'spray') return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', ...style }}>
      <div style={{ width: 10, height: 10, background: t.accent, borderRadius: 999 }}/>
      <div style={{ width: 24, height: 4, background: t.ink, transform: 'skewX(-18deg)' }}/>
      <div style={{ width: 8, height: 8, background: t.accent2, borderRadius: 999 }}/>
      <div style={{ width: 14, height: 3, background: t.accent }}/>
      <div style={{ width: 5, height: 5, background: t.ink, borderRadius: 999 }}/>
    </div>
  );
  if (t.ornament === 'care') return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, ...style }}>
      <div style={{ width: 30, height: 1, background: t.accent }}/>
      <svg width="12" height="12" viewBox="0 0 12 12"><path d="M6 1 L7.5 4.5 L11 6 L7.5 7.5 L6 11 L4.5 7.5 L1 6 L4.5 4.5 Z" fill={t.accent}/></svg>
      <div style={{ width: 30, height: 1, background: t.accent }}/>
    </div>
  );
  // minimal / none
  return <div style={{ width: 32, height: 1, background: t.line, ...style }}/>;
}

// ── Star row ──
function StarRow({ t, n = 5, size = 12 }) {
  return (
    <div style={{ display: 'flex', gap: 2, color: t.accent }}>
      {Array.from({length: 5}).map((_, i) => (
        <svg key={i} width={size} height={size} viewBox="0 0 12 12" fill={i < n ? t.accent : 'none'} stroke={t.accent} strokeWidth="1">
          <path d="M6 1l1.5 3.3 3.5.4-2.6 2.4.8 3.5L6 8.9 2.8 10.6l.8-3.5L1 4.7l3.5-.4L6 1z"/>
        </svg>
      ))}
    </div>
  );
}

// ── Headline that applies theme display rules ──
function Headline({ t, children, size = 36, style = {}, italic }) {
  return (
    <h1 style={{
      fontFamily: t.display,
      fontWeight: t.displayWeight,
      fontSize: size,
      lineHeight: 1.02,
      letterSpacing: `${t.displayTracking}em`,
      margin: 0,
      color: t.ink,
      fontStyle: italic ? 'italic' : 'normal',
      textWrap: 'pretty',
      textTransform: t.id === 'street' ? 'uppercase' : 'none',
      ...style,
    }}>{children}</h1>
  );
}

function Body({ t, children, size = 14, color, style = {} }) {
  return (
    <p style={{
      fontFamily: t.body,
      fontSize: size, lineHeight: 1.55,
      color: color || t.ink,
      margin: 0, textWrap: 'pretty',
      ...style,
    }}>{children}</p>
  );
}

Object.assign(window, {
  Placeholder, TButton, Kicker, Ornament, StarRow, Headline, Body,
});
